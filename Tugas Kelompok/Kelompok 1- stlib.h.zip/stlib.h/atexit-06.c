#include <stdio.h>
#include <stdlib.h>

int main()
{
    atexit(printf("Program selesai! Terima kasih telah menggunakan program kami.\n"));

    printf("Selamat Program mulai");
}